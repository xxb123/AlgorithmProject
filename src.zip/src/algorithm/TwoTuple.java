package algorithm;

/**
 * Created by Theodore on 6/19/2015.
 */
public class TwoTuple<A, B> {
    private A first;
    private B second;

    public A getFirst() {
        return first;
    }
    public B getSecond() {
        return second;
    }

    public void setFirst(A first) {
        this.first = first;
    }

    public void setSecond(B second) {
        this.second = second;
    }
}
